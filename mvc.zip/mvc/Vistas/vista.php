<?php
include_once "../encabezado.php";


?>

<!DOCTYPE html>
<html lang="en">
<head>
<script>
	
	function eliminar(id)
	{
		if(confirm("¿ Estas seguro de eliminar el registro ?"))
		{
			window.location = "../Controlador/controlador.php?ideliminar=" + id;
		}
	}

	function modificar(id)
	{
		window.location = "../Controlador/controlador.php?idmodificar=" + id;
	}
</script>

</head>

<table class="table table-bordered table-sm" cellspacing="0" width="100%">
<header class="bg-gradient text-white">
            <div class="container px-4 text-center">
<body style="background-color: black;">	
	<center>
<h1>Registro de Categorias</h1>
	<form action="../Controlador/controlador.php" id="frminsertar" name="frminsertar" method="post">
		<!-- <label for="">Numero: </label> -->
		<input type="text" id="txtid" name="txtid" value="<?php echo @$buscar_mod[0][0]; ?>" hidden>
		<br>

		<div class="row g-2">
		<br>
		<label style="font-size: 30px;">Nombre de la categoria: </label>
		<input type="text" id="txtnombre" class="form-control" name="txtnombre" value="<?php echo @$buscar_mod[0][1]; ?>" required>
		<br>
		<br>
		<label style="font-size: 30px;">Fecha: </label>
		<input type="date" id="txtfecha" class="form-control" name="txtfecha" value="<?php echo @$buscar_mod[0][2]; ?>" required >
		<br>
		</div>
		<br>
		<button type="submit" class="btn btn-outline-light" id="btninsertar" name="btninsertar" value="<?php if(isset($_GET['idmodificar']))
		{ 
			echo 'Modificar';
		}
		else
		{
			echo 'Insertar';
		}
		 ?>">Insertar</button>
	</form>
	</center>
	<br><br>
	
	<form action="../Controlador/controlador.php" id="frmbuscar" name="frmbuscar" method="post">
		
		
		<table  class="table table-dark table-striped">
		<div style="text-align: left;">
		
		<input type="text" class="btn btn-outline-light" id="txtbuscar" name="txtbuscar" >
		<button type="submit" class="btn btn-outline-light" id="btnbuscar" name="btnbuscar" value="Buscar" ><i class="fa-solid fa-magnifying-glass"></i></button>
		</div>
		<br>
			<tr>
				<td align="center" >Número</td>
				<td align="center" >Nombre</td>
				<td align="center" >Fecha</td>
				<td colspan="2" align="center">Accion</td>
			</tr>
			<?php echo @$datos; ?>
		</table>
	</form>


</body>
</html>