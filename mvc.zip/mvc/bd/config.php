<?php 

define('DB_SERVER', '127.0.0.1:3308');
define('DB_NAME', 'aw2022');
define('DB_USER', 'root');
define('DB_PASS', '');

 ?>