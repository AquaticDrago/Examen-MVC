<?php
header("Location:Vistas/vista.php")
?>